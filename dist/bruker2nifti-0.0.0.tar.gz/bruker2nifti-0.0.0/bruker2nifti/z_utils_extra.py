
# def set_new_data(image, new_data, new_dtype=None, remove_nan=True):
#     """
#     From a nibabel image and a numpy array it creates a new image with
#     the same header of the image and the new_data as its data.
#     :param image: nibabel image
#     :param new_data: numpy array
#     :return: nibabel image
#     """
#     if new_dtype is not None:
#         new_data = new_data.astype(new_dtype)
#     if remove_nan:
#         new_data = np.nan_to_num(new_data)
#
#     # if nifty1
#     if image.header['sizeof_hdr'] == 348:
#         new_image = nib.Nifti1Image(new_data, image.affine, header=image.header)
#     # if nifty2
#     elif image.header['sizeof_hdr'] == 540:
#         new_image = nib.Nifti2Image(new_data, image.affine, header=image.header)
#     else:
#         raise IOError('Input image header problem')
#
#     return new_image
#
#
#
# def separate_shells_txt(b_vals, b_vects, num_initial_dir_to_skip=7, num_shells=3):
#     """
#
#     :param b_vals: input b-values
#     :param b_vects: input b-vectors
#     :param num_initial_dir_to_skip: Non all the initial values of the b-vals b-vects are useful. Where to start?
#     :param num_shells:
#     :return [[bvals splitted], [bvect splitted]]:
#      a different list for each shell for b-vals and b-vect
#     """
#     b_vals = b_vals[num_initial_dir_to_skip:]
#     b_vects = b_vects[num_initial_dir_to_skip:]
#
#     b_vals_per_shell = []
#     b_vect_per_shell = []
#
#     for k in range(num_shells):
#         b_vals_per_shell.append(b_vals[k::num_shells])
#         b_vect_per_shell.append(b_vects[k::num_shells])
#
#     # sanity check
#     num_directions = len(b_vals_per_shell[0])
#     for k in range(num_shells):
#         if not len(b_vals_per_shell[k]) == len(b_vect_per_shell[k]) == num_directions:
#             raise IOError
#
#     return [b_vals_per_shell, b_vect_per_shell]
#
#
# def separate_shells_txt_path(b_vals_path, b_vects_paths, output_folder=None, prefix='',
#                              num_initial_dir_to_skip=7, num_shells=3):
#     """
#
#     :param b_vals_path:
#     :param b_vects_paths:
#     :param output_folder: folder where to save the parameters.
#     :param prefix : prefix for the file as the subject tag. Empty string by default.
#     :param num_initial_dir_to_skip:
#     :param num_shells:
#     :return:
#     """
#     if output_folder is None:
#         output_folder = os.path.dirname(b_vals_path)
#
#     b_vals = np.loadtxt(b_vals_path)
#     b_vects = np.loadtxt(b_vects_paths)
#
#     [list_b_vals, list_b_vects] = separate_shells_txt(b_vals,
#                                                       b_vects,
#                                                       num_initial_dir_to_skip=num_initial_dir_to_skip,
#                                                       num_shells=num_shells)
#
#     # save here the bvals and bvects in separate lists.
#     for i in range(num_shells):
#         path_b_vals_shell_i = os.path.join(output_folder, prefix + '_DwEffBval_shell' + str(i) + '.txt')
#         path_b_vect_shell_i = os.path.join(output_folder, prefix + '_DwGradVec_shell' + str(i) + '.txt')
#
#         np.savetxt(path_b_vals_shell_i, list_b_vals[i])
#         print 'B-values for shell {0} saved in {1}'.format(str(i), path_b_vect_shell_i)
#
#         np.savetxt(path_b_vect_shell_i, list_b_vects[i])
#         print 'B-vectors for shell {0} saved in {1}'.format(str(i), path_b_vals_shell_i)
#
#
# def matrix_per_list_of_arrays(in_matrix, in_array):
#     """
#     given a matrix nxn and another array of dimension mxn, it multiplies the
#     nxn matrix times each row of the second array, returning an array of the
#     same dimension as in_array.
#     :param in_matrix:
#     :param in_array:
#     :return:
#     """
#     return np.array([in_matrix.dot(in_array[i, :]) for i in range(in_array.shape[0])])
#
#
# def parse_bruker_dwi_txt(input_path_txt,
#                          output_folder,
#                          output_type=np.float,
#                          file_to_save=('DwDir=', 'DwEffBval=', 'DwGradVec=', 'VisuCoreDataSlope='),
#                          num_col_to_reshape=(1, 1, 3, 1),
#                          prefix='',
#                          rotation=None,
#                          normalize=True):
#     clear_cache()
#
#     for line in open(input_path_txt, 'r'):
#         for j in range(len(file_to_save)):
#
#             msg = ''
#             if line.startswith(file_to_save[j]):
#                 in_array_as_string = line.replace(']', '[').split('[')[1]
#                 in_array = np.array(map(float, in_array_as_string.split(' ')), dtype=output_type)
#                 len_array = np.prod(in_array.shape)
#
#                 # reshape according to num_col_to_reshape
#                 if len_array % num_col_to_reshape[j] == 0:
#                     new_shape = [len_array / num_col_to_reshape[j], num_col_to_reshape[j]]
#                     in_array = in_array.reshape(new_shape)
#
#                     # normalise if we are dealing with non-empty b-vectors:
#                     if file_to_save[j] == 'DwGradVec=':
#                         if normalize:
#                             row_sums = in_array.sum(axis=1)
#                             # comment next line if you want nan when the mean is zero instead of zero
#                             row_sums[row_sums == 0.0] = 1.0
#                             in_array = in_array / row_sums[:, np.newaxis]
#
#                             # in_array = np.nan_to_num(in_array)
#                             # print row_sums[:, np.newaxis]
#                             msg = ' (Normalized)'
#                         if rotation is not None:
#                             in_array = matrix_per_list_of_arrays(rotation, in_array)
#                             msg += ' oriented according to {0}'.format(rotation)
#
#                 else:
#                     raise IOError('Not compatible num_col_to_reshape in input.')
#
#                 filename_path = os.path.join(output_folder, prefix + file_to_save[j][:-1] + '.txt')
#                 np.savetxt(filename_path, in_array, fmt='%.14f')
#
#                 msg = 'Array ' + file_to_save[j][:-1] + ' saved in ' + filename_path + msg
#                 print(msg)
#
#
# def corrector_MSME_T2_path(pfi_input, pfi_output, modality=None, swap_dim=None):
#     """
#     Remapping of the MSME T2 from paravision to a nifty format where
#     (x,y,z,e) are the x,y,z, coordinates of the volume and e are the echo coordinates.
#     --------
#     ex_vivo:
#     --------
#     The input files presents with 2 consecutive slices with echoes in the same z slice.
#
#     As it is       | as we like it to be
#     ----------------------------------
#     (x,y,0:15,0)   | (x,y,0,0:15)
#     (x,y,16:32,0)  | (x,y,1,0:15)
#     (x,y,0:15,1)   | (x,y,2,0:15)
#     (x,y,16:32,1)  | (x,y,3,0:15)
#     (x,y,0:15,2)   | (x,y,4,0:15)
#     (x,y,16:32,2)  | (x,y,5,0:15)
#       ...            ...
#     (x,y,0:15,t)   | (x,y,2*t,0:15)
#     (x,y,16:32,t)  | (x,y,2*t+1,0:15)
#
#     In addition, it will reorient the image in a proper way!
#
#     :param:
#     :return:
#     """
#     im = nib.load(pfi_input)
#     im_data = im.get_data()
#
#     # Reslice:
#     sh = im_data.shape
#
#     stack_data = np.zeros((sh[0], sh[1], sh[2] * sh[3]), dtype=np.float64)
#     new_data = np.zeros_like(im_data)
#
#     for t in xrange(sh[3]):
#         m = sh[2] * t
#         M = sh[2] * t + sh[2]
#         stack_data[:, :, m:M] = im_data[..., t]
#
#     for z in xrange(sh[2]):
#         m = sh[3] * z
#         M = sh[3] * z + sh[3]
#         new_data[:, :, z, :] = stack_data[:, :, m:M]
#
#     im_new = set_new_data(im, new_data)
#     nib.save(im_new, pfi_output)
#
#     if modality == 'ex_vivo':
#         swap_dim = 'x z -y'
#
#     elif modality == 'in_vivo':
#         swap_dim = 'x z -y'
#
#     # swap dimension according to swap_dim or modality.
#     if swap_dim is not None:
#         print('Reorienting directions according to {} .'.format(swap_dim))
#
#         cmd = 'fslorient -deleteorient {0}; ' \
#               'fslswapdim {0} {1} {0}; ' \
#               'fslorient -setqformcode 1 {0}; '.format(pfi_output, swap_dim)
#         os.system(cmd)