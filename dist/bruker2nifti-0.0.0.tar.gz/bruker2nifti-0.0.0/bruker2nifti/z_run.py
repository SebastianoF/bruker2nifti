import numpy as np
import nibabel as nib
import os
from bruker2nifti.scan_converter import write_scan_to_nifti, get_info_and_img_data, convert_a_scan
from bruker2nifti.study_converter import show_study_structure, get_info_sj, get_subject_name, get_subject_id,\
    convert_a_study


# scan 3 is the DWI
# pfi_ans_dwi = '/Users/sebastiano/Desktop/test_PV/niftiTestResults/dwi.nii.gz'
# pfi_scan3_pv5 = '/Users/sebastiano/Desktop/test_PV/pv5/1305/3'
#
# info, img_data = get_info_and_img_data(pfi_scan3_pv5)
# write_scan_to_nifti(info, img_data, pfi_ans_dwi, correct_slope=False)
#
# os.system('fslhd {}'.format(pfi_ans_dwi))


# scan 4 is the 3d
# pfi_ans_3d = '/Users/sebastiano/Desktop/test_PV/niftiTestResults/3d.nii.gz'
# pfi_scan4_pv5 = '/Users/sebastiano/Desktop/test_PV/pv5/1305/4'
#
#
# info, img_data = get_info_and_img_data(pfi_scan4_pv5)
# write_scan_to_nifti(info, img_data, pfi_ans_3d, correct_slope=False,
#                     qform=2, sform=1, axis_direction=(-1,-1,1))
#
# os.system('fslhd {}'.format(pfi_ans_3d))


# convert_a_scan('/Users/sebastiano/Desktop/test_PV/pv5/1305/4',
#                '/Users/sebastiano/Desktop/test_PV/new')



# show_study_structure('/Users/sebastiano/Desktop/test_PV/pv5/1305')

get_subject_name('/Users/sebastiano/Desktop/test_PV/pv5/1305')
get_subject_id('/Users/sebastiano/Desktop/test_PV/pv5/1305')

convert_a_study('/Users/sebastiano/Desktop/test_PV/pv5/1305', '/Users/sebastiano/Desktop/test_PV')
